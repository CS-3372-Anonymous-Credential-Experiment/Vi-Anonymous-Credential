// RPC functionality removed - handle smart contract testing through your own RPC setup
