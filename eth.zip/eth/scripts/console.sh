# RPC functionality removed - handle RPC connectivity yourself
