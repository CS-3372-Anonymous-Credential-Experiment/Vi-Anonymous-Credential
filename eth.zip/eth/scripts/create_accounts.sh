# RPC functionality removed - handle account creation through your own RPC setup
