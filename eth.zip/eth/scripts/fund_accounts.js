// RPC functionality removed - handle account funding through your own RPC setup
